from random import randint
# 1. 랜덤 함수를 사용하여 생성된 값이 짝수 또는 홀수 인지를 구분하는
# 코드를 작성하시오.
rand = randint(10, 99)
if rand % 2 == 0:
    print('짝수')
else:
    print('홀수')

# 2. 랜덤 함수를 사용하여 생성된 2개의 값을 빼기 계산 할 때 항상 양의
# 정수가 나올 수 있도록 하시오.
rand1 = randint(10, 99)
rand2 = randint(10, 99)
if rand1 > rand2:
    print('{} - {} = {}'.format(rand1, rand2, rand1 - rand2))
else:
    print('{} - {} = {}'.format(rand2, rand1, rand2 - rand1))

# 3. 랜덤 함수를 사용하여 생성된 2개의 값을 홀/짝 비교하였을 때 2개의
# 값이 전부 홀수 또는 짝수이면, 2개의 정수 값을 더하고 2개의
# 값이 홀-짝 또는 짝-홀이면, 2개의 정수 값을 곱하시오.
rand1 = randint(10, 99)
rand2 = randint(10, 99)
if (rand1 % 2 == 0 and rand2 % 2 == 0) or\
    (rand1 % 2 == 1 and rand2 % 2 == 1):
    print('{} + {} = {}'.format(rand1, rand2, rand1 + rand2))
else:
    print('{} * {} = {}'.format(rand1, rand2, rand1 * rand2))

# 4. 랜덤 함수를 통해 생성 된 2개의 값(10 ~ 99 까지)으로 더하기 문제를
# 만들고 만들어진 문제를 사용자가 풀어보는 형식의 코드를 작성하시오.
rand1 = randint(10, 99)
rand2 = randint(10, 99)

result = rand1 + rand2
if result == int(input('{} - {} = '.format(rand1, rand2))):
    print('정답')
else:
    print('오답')
