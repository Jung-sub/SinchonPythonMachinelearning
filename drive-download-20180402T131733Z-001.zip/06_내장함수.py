print(sum([1,3,5]))
print(pow(2,3))
print(divmod(3,3))
print(round(123.355,2))