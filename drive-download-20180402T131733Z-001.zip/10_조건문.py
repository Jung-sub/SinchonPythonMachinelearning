for x in range(1,10):
    for y in range(1,10):
        print('{} * {} = {}'.format(x, y, x*y))
    print() # 개행 때문에 한다
