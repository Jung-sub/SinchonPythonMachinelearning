#1. 1 ~ 20 까지의 정수 값을 출력하는 코드를 작성 하시오.(while문으로만 작성)
x = 1
while x <= 20:
    print(x)
    x = x + 1

#2. 1 ~ 100 까지의 누적 합을 구하는 코드를 작성 하시오.(while문으로만 작성)
x = 1
tot = 0
while x <= 100:
    tot = tot + x
    x = x + 1
print(tot)

#3. 사용자가 입력한 값을 초과하지 않는 한도에서의 누적 합을 구하는 코드를 작성 하시오
userin = int(input('사용자 입력:'))
x = 1
tot = 0
while True:
    if tot + x >= userin:
        break
    tot = tot + x
    x = x + 1
print(tot)
